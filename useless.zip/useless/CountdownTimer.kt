package trashpixl.trashpixl.useless //defining the class package

class CountdownTimer { //creating the class
    fun countdownTimer() { //creating the main function

    }
}